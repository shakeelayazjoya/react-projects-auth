// api/Axios.js
import axios from "axios";

export default axios.create({
  baseURL: "http://localhost:3000", // Set this to your server's base URL
});
